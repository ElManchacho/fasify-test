const awsLambdaFastify = require('@fastify/aws-lambda')
const server = require('./server');

//const proxy = awsLambdaFastify(server, { binaryMimeTypes: ['application/octet-stream'] })

exports.handler = server;